import asyncio
import json
from contextlib import asynccontextmanager
from pathlib import Path

from telethon import TelegramClient
from telethon.sessions import StringSession
from java import jclass

Vault = jclass("org.example.telegramtextexport.SessionVault")
from telethon.errors import SessionPasswordNeededError
from telethon.network.connection import ConnectionTcpObfuscated

_code_hash = None


def _client(directory, api_id, api_hash, proxy_host, proxy_port, proxy_user, proxy_password):
    Path(directory).mkdir(parents=True, exist_ok=True)
    proxy = None
    if proxy_host.strip():
        proxy = {"proxy_type": "socks5", "addr": proxy_host.strip(),
                 "port": int(proxy_port), "rdns": True}
        if proxy_user:
            proxy["username"] = proxy_user
            proxy["password"] = proxy_password
    return TelegramClient(StringSession(str(Vault.read("session"))), int(api_id), api_hash,
                          receive_updates=False, connection=ConnectionTcpObfuscated,
                          proxy=proxy, timeout=8, connection_retries=2)


@asynccontextmanager
async def _connected(directory, api_id, api_hash, proxy_host, proxy_port, proxy_user, proxy_password):
    client = _client(directory, api_id, api_hash, proxy_host, proxy_port,
                     proxy_user, proxy_password)
    try:
        await client.connect()
        yield client
    finally:
        try:
            Vault.write("session", StringSession.save(client.session) if client.session and client.session.auth_key else "")
        finally:
            await client.disconnect()


async def _send_code(directory, api_id, api_hash, phone, *proxy):
    global _code_hash
    async with _connected(directory, api_id, api_hash, *proxy) as client:
        if await client.is_user_authorized():
            return "authorized"
        result = await client.send_code_request(phone)
        _code_hash = result.phone_code_hash
        return "code_sent"


def send_code(directory, api_id, api_hash, phone, *proxy):
    return asyncio.run(_send_code(directory, api_id, api_hash, phone, *proxy))


async def _sign_in(directory, api_id, api_hash, phone, code, *proxy):
    async with _connected(directory, api_id, api_hash, *proxy) as client:
        if await client.is_user_authorized():
            return "authorized"
        try:
            await client.sign_in(phone=phone, code=code, phone_code_hash=_code_hash)
            return "authorized"
        except SessionPasswordNeededError:
            return "password_required"


def sign_in(directory, api_id, api_hash, phone, code, *proxy):
    return asyncio.run(_sign_in(directory, api_id, api_hash, phone, code, *proxy))


async def _password(directory, api_id, api_hash, password, *proxy):
    async with _connected(directory, api_id, api_hash, *proxy) as client:
        await client.sign_in(password=password)
        return "authorized"


def password(directory, api_id, api_hash, value, *proxy):
    return asyncio.run(_password(directory, api_id, api_hash, value, *proxy))


async def _dialogs(directory, api_id, api_hash, *proxy):
    async with _connected(directory, api_id, api_hash, *proxy) as client:
        if not await client.is_user_authorized():
            raise ValueError("Сессия не авторизована. Войдите снова.")
        results = []
        async for dialog in client.iter_dialogs():
            if dialog.is_user and not getattr(dialog.entity, "bot", False):
                results.append({"id": dialog.entity.id, "name": dialog.name})
        return json.dumps(results, ensure_ascii=False)


def dialogs(directory, api_id, api_hash, *proxy):
    return asyncio.run(_dialogs(directory, api_id, api_hash, *proxy))


async def _export(directory, api_id, api_hash, peer_id, output, *proxy):
    count = 0
    async with _connected(directory, api_id, api_hash, *proxy) as client:
        if not await client.is_user_authorized():
            raise ValueError("Сессия не авторизована. Войдите снова.")
        # StringSession intentionally keeps no plaintext entity/contact database.
        peer = None
        async for dialog in client.iter_dialogs():
            if dialog.is_user and dialog.entity.id == int(peer_id):
                peer = dialog.input_entity
                break
        if peer is None:
            raise ValueError("Диалог не найден. Загрузите список заново.")
        with open(output, "w", encoding="utf-8") as destination:
            destination.write("Экспорт личного чата Telegram (UTC)\n\n")
            async for message in client.iter_messages(peer, reverse=True):
                content = message.raw_text
                if not content:
                    continue
                time = message.date.strftime("%Y-%m-%d %H:%M:%S")
                author = "Я" if message.out else "Собеседник"
                destination.write(f"[{time}] {author}: {content}\n\n")
                count += 1
    return count


def export(directory, api_id, api_hash, peer_id, output, *proxy):
    return asyncio.run(_export(directory, api_id, api_hash, peer_id, output, *proxy))


async def _logout(directory, api_id, api_hash, *proxy):
    global _code_hash
    async with _connected(directory, api_id, api_hash, *proxy) as client:
        if not await client.log_out():
            raise ValueError("Не удалось завершить сессию. Повторите выход.")
    Vault.clear()
    _code_hash = None
    return "logged_out"


def logout(directory, api_id, api_hash, *proxy):
    return asyncio.run(_logout(directory, api_id, api_hash, *proxy))
