# Java entry point used from Python through jclass. These names must remain stable.
-keep class org.example.telegramtextexport.SessionVault { public static *; }
# Retain the encoded storage representation; renaming is allowed, constant folding is not.
-keep,allowobfuscation class org.example.telegramtextexport.Credentials { *; }
# Runtime Java/Python bridge uses reflection and native entry points.
-keep class com.chaquo.python.** { *; }
-keepattributes Signature,InnerClasses,EnclosingMethod,*Annotation*
