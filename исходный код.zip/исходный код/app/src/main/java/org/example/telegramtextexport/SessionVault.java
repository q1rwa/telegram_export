package org.example.telegramtextexport;

import android.content.Context;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.AtomicFile;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import javax.crypto.*;
import javax.crypto.spec.GCMParameterSpec;

/** Only encrypted blobs are persisted; the AES key stays in Android Keystore. */
public final class SessionVault {
    private static Context context;
    private static final String ALIAS = "telegram_export_v2";
    public static void init(Context value) { context = value.getApplicationContext(); }
    private static AtomicFile file(String name) {
        return new AtomicFile(new File(context.getNoBackupFilesDir(), name + ".enc"));
    }
    private static SecretKey key() throws Exception {
        KeyStore store = KeyStore.getInstance("AndroidKeyStore"); store.load(null);
        if (!store.containsAlias(ALIAS)) {
            KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
            generator.init(new KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());
            generator.generateKey();
        }
        return (SecretKey) store.getKey(ALIAS, null);
    }
    public static synchronized String read(String name) throws Exception {
        if (!file(name).getBaseFile().exists() && !new File(file(name).getBaseFile().getPath() + ".bak").exists()) return "";
        byte[] blob = file(name).readFully();
        if (blob.length < 29) throw new IOException("Повреждено защищённое хранилище");
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE, key(), new GCMParameterSpec(128, blob, 0, 12));
        cipher.updateAAD(name.getBytes(StandardCharsets.UTF_8));
        return new String(cipher.doFinal(blob, 12, blob.length - 12), StandardCharsets.UTF_8);
    }
    public static synchronized void write(String name, String value) throws Exception {
        if (value.isEmpty()) { file(name).delete(); return; }
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding"); cipher.init(Cipher.ENCRYPT_MODE, key());
        cipher.updateAAD(name.getBytes(StandardCharsets.UTF_8));
        byte[] encrypted = cipher.doFinal(value.getBytes(StandardCharsets.UTF_8));
        AtomicFile target = file(name); FileOutputStream out = null;
        try { out = target.startWrite(); out.write(cipher.getIV()); out.write(encrypted); target.finishWrite(out); }
        catch (Exception error) { if (out != null) target.failWrite(out); throw error; }
    }
    public static synchronized void clear() throws Exception {
        file("session").delete(); file("settings").delete();
        KeyStore store = KeyStore.getInstance("AndroidKeyStore"); store.load(null); store.deleteEntry(ALIAS);
    }
}
