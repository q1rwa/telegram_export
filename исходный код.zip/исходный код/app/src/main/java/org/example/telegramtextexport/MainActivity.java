package org.example.telegramtextexport;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.Rect;
import android.content.res.ColorStateList;
import android.graphics.drawable.RippleDrawable;
import android.view.MotionEvent;
import android.view.inputmethod.InputMethodManager;
import android.widget.ProgressBar;
import android.widget.Toast;
import android.widget.FrameLayout;
import android.view.Gravity;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;

import com.chaquo.python.Python;
import com.chaquo.python.PyObject;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private EditText apiId, apiHash, phone, code, password;
    private EditText proxyHost, proxyPort, proxyUser, proxyPassword;
    private Spinner chats;
    private TextView status;
    private Button sendCode, signIn, enterPassword, loadChats, export, logout;
    private String[] values;
    private final int blue = Color.rgb(51,144,236);
    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density); }
    private LinearLayout root;
    private final ArrayList<Long> chatIds = new ArrayList<>();
    private File exportFile;
    private ProgressBar progress;
    private TextView floatingMessage;
    private boolean overrideApi = false;
    private final android.os.Handler messageHandler = new android.os.Handler(android.os.Looper.getMainLooper());
    private final Runnable dismissMessage = () -> { if (floatingMessage != null) floatingMessage.animate().alpha(0f).setDuration(160).withEndAction(() -> floatingMessage.setVisibility(View.GONE)).start(); };

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SessionVault.init(this);
        cleanExports();
        getWindow().setStatusBarColor(Color.rgb(18,22,28));
        getWindow().setNavigationBarColor(Color.rgb(18,22,28));
        LinearLayout column = new LinearLayout(this);
        column.setOrientation(LinearLayout.VERTICAL);
        root = column;
        column.setBackgroundColor(Color.rgb(18,22,28));
        int padding = (int) (16 * getResources().getDisplayMetrics().density);
        column.setPadding(padding, padding, padding, padding);
        ScrollView scroll = new ScrollView(this);
        scroll.setOnApplyWindowInsetsListener((view, insets) -> {
            view.setPadding(insets.getSystemWindowInsetLeft(), insets.getSystemWindowInsetTop(), insets.getSystemWindowInsetRight(), insets.getSystemWindowInsetBottom());
            if (floatingMessage != null) {
                FrameLayout.LayoutParams messageParams = (FrameLayout.LayoutParams)floatingMessage.getLayoutParams();
                messageParams.bottomMargin = dp(16) + insets.getSystemWindowInsetBottom(); floatingMessage.setLayoutParams(messageParams);
            }
            return insets.consumeSystemWindowInsets();
        });
        scroll.addView(column);
        FrameLayout frame = new FrameLayout(this); frame.setBackgroundColor(Color.rgb(18,22,28));
        frame.addView(scroll, new FrameLayout.LayoutParams(-1,-1));
        floatingMessage = new TextView(this); floatingMessage.setTextColor(Color.WHITE); floatingMessage.setTextSize(15);
        floatingMessage.setPadding(dp(16),dp(14),dp(16),dp(14)); floatingMessage.setMaxLines(5);
        GradientDrawable toastBackground = new GradientDrawable(); toastBackground.setColor(Color.argb(235,35,44,57)); toastBackground.setCornerRadius(dp(14));
        floatingMessage.setBackground(toastBackground); floatingMessage.setElevation(dp(8)); floatingMessage.setVisibility(View.GONE);
        FrameLayout.LayoutParams toastParams = new FrameLayout.LayoutParams(-1,-2,Gravity.BOTTOM);
        toastParams.leftMargin=dp(16); toastParams.rightMargin=dp(16); toastParams.bottomMargin=dp(32);
        frame.addView(floatingMessage,toastParams); setContentView(frame);

        TextView heading = new TextView(this);
        heading.setText("Экспорт личного чата Telegram");
        heading.setTextSize(22);
        heading.setTextColor(Color.WHITE); heading.setTypeface(null, Typeface.BOLD);
        column.addView(heading);
        TextView build = new TextView(this); build.setText("v1.0 · сборка 7"); build.setTextSize(12); build.setTextColor(Color.rgb(166,180,200)); column.addView(build);
        TextView hint = new TextView(this);
        hint.setTextColor(Color.rgb(166,180,200));
        hint.setPadding(0,dp(8),0,dp(14));
        hint.setText("Войдите по номеру телефона и коду из Telegram. Сессия хранится зашифрованно на устройстве. Экспорт сохраняет текст и подписи к медиа; файлы не скачиваются.");
        column.addView(hint);

        column = card(root, "Вход в Telegram");
        LinearLayout advanced = new LinearLayout(this); advanced.setOrientation(LinearLayout.VERTICAL); advanced.setVisibility(View.GONE);
        button(column, "Дополнительные настройки API", () -> advanced.setVisibility(advanced.getVisibility() == View.GONE ? View.VISIBLE : View.GONE));
        column.addView(advanced);
        android.widget.CheckBox ownApi = new android.widget.CheckBox(this); ownApi.setText("Использовать собственные API-данные"); ownApi.setTextColor(Color.WHITE); advanced.addView(ownApi);
        apiId = field(advanced, "API ID", InputType.TYPE_CLASS_NUMBER);
        apiHash = field(advanced, "API Hash", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        apiId.setEnabled(false); apiHash.setEnabled(false);
        ownApi.setOnCheckedChangeListener((button, checked) -> { overrideApi = checked; apiId.setEnabled(checked); apiHash.setEnabled(checked); });
        phone = field(column, "Номер в международном формате: +7…", InputType.TYPE_CLASS_PHONE);
        code = field(column, "Код из Telegram", InputType.TYPE_CLASS_TEXT);
        password = field(column, "Облачный пароль (если включён)", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        password.setVisibility(View.GONE);

        LinearLayout loginCard = column;
        column = card(root, "SOCKS5-прокси · необязательно");
        TextView proxyHint = new TextView(this);
        proxyHint.setText("Если соединение с Telegram не работает, включите VPN на телефоне или введите SOCKS5-прокси ниже. Если прокси не нужен, оставьте поля пустыми.");
        proxyHint.setTextColor(Color.rgb(166,180,200));
        column.addView(proxyHint);
        proxyHost = field(column, "SOCKS5: адрес сервера (необязательно)", InputType.TYPE_CLASS_TEXT);
        proxyPort = field(column, "SOCKS5: порт", InputType.TYPE_CLASS_NUMBER);
        proxyUser = field(column, "SOCKS5: логин (если нужен)", InputType.TYPE_CLASS_TEXT);
        proxyPassword = field(column, "SOCKS5: пароль (если нужен)", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);

        sendCode = button(loginCard, "Получить код", () -> runTask(() -> {
            String result = bridge().callAttr("send_code", sessionDir(), api(), hash(), values[2].trim(), proxyHost(), proxyPort(), proxyUser(), proxyPassword()).toString();
            show(result.equals("authorized") ? "Вход уже выполнен. Загрузите диалоги." : "Код отправлен. Введите его ниже.");
        }));
        signIn = button(loginCard, "Войти с кодом", () -> runTask(() -> {
            String result = bridge().callAttr("sign_in", sessionDir(), api(), hash(), values[2].trim(), values[3].trim(), proxyHost(), proxyPort(), proxyUser(), proxyPassword()).toString();
            if (!result.equals("password_required")) runOnUiThread(() -> code.setText(""));
            show(result.equals("password_required") ? "Введите облачный пароль." : "Вход выполнен. Загрузите диалоги.");
            if (result.equals("password_required")) runOnUiThread(() -> { password.setVisibility(View.VISIBLE); enterPassword.setVisibility(View.VISIBLE); });
        }));
        enterPassword = button(loginCard, "Подтвердить пароль", () -> runTask(() -> {
            bridge().callAttr("password", sessionDir(), api(), hash(), values[4], proxyHost(), proxyPort(), proxyUser(), proxyPassword());
            runOnUiThread(() -> password.setText(""));
            show("Вход выполнен. Загрузите диалоги.");
        }));
        enterPassword.setVisibility(View.GONE);
        column = card(root, "Экспорт переписки");
        loadChats = button(column, "Загрузить личные диалоги", () -> runTask(() -> {
            JSONArray data = new JSONArray(bridge().callAttr("dialogs", sessionDir(), api(), hash(), proxyHost(), proxyPort(), proxyUser(), proxyPassword()).toString());
            ArrayList<String> names = new ArrayList<>();
            ArrayList<Long> ids = new ArrayList<>();
            for (int i = 0; i < data.length(); i++) {
                JSONObject item = data.getJSONObject(i);
                names.add(item.getString("name"));
                ids.add(item.getLong("id"));
            }
            runOnUiThread(() -> {
                chatIds.clear(); chatIds.addAll(ids);
                chats.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, names));
                show("Личных диалогов: " + names.size());
            });
        }));
        chats = new Spinner(this);
        column.addView(chats);
        export = button(column, "Экспортировать выбранный чат", () -> {
            int position = chats.getSelectedItemPosition();
            if (position < 0 || position >= chatIds.size()) { show("Сначала загрузите и выберите диалог."); return; }
            long id = chatIds.get(position);
            runTask(() -> {
                exportFile = new File(getCacheDir(), "telegram-chat-export.txt");
                int count = bridge().callAttr("export", sessionDir(), api(), hash(), id, exportFile.getAbsolutePath(), proxyHost(), proxyPort(), proxyUser(), proxyPassword()).toInt();
                show("Подготовлено текстовых сообщений: " + count + ". Выберите место сохранения.");
                runOnUiThread(() -> {
                    Intent save = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    save.addCategory(Intent.CATEGORY_OPENABLE);
                    save.setType("text/plain");
                    save.putExtra(Intent.EXTRA_TITLE, "telegram-chat-" + id + ".txt");
                    startActivityForResult(save, 101);
                });
            });
        });
        column = root;
        logout = button(column, "Выйти из Telegram", () -> new AlertDialog.Builder(this)
            .setTitle("Выйти из Telegram?")
            .setMessage("Сессия будет завершена в Telegram, а данные входа удалены с устройства. Сохранённые вами TXT-файлы останутся.")
            .setNegativeButton("Отмена", null)
            .setPositiveButton("Выйти", (dialog, which) -> runTask(() -> {
                bridge().callAttr("logout", sessionDir(), api(), hash(), proxyHost(), proxyPort(), proxyUser(), proxyPassword());
                cleanExports();
                runOnUiThread(() -> {
                    for (EditText field : fields()) field.setText("");
                    password.setVisibility(View.GONE); enterPassword.setVisibility(View.GONE); ownApi.setChecked(false); chatIds.clear(); chats.setAdapter(null);
                });
                show("Вы вышли из Telegram. Данные входа удалены.");
            })).show());
        logout.setTextColor(Color.rgb(255,100,110));
        progress = new ProgressBar(this); progress.setVisibility(View.GONE);
        column.addView(progress, new LinearLayout.LayoutParams(dp(36),dp(36)));
        status = new TextView(this);
        status.setText("Данные входа и сессия зашифрованы на устройстве. Сохранение текста — только в выбранный вами файл.");
        status.setTextColor(Color.rgb(166,180,200)); status.setPadding(0,dp(12),0,dp(12));
        column.addView(status);
        TextView privacy = new TextView(this);
        privacy.setText("При закрытии приложения вход сохраняется. TXT не зашифрован: при выборе облачного хранилища файл будет передан этому сервису.");
        privacy.setTextColor(Color.rgb(166,180,200)); column.addView(privacy);
        TextView credits = new TextView(this);
        credits.setText("Создатель: tg @s314rgy\nКанал: t.me/q1rwa");
        credits.setTextColor(blue); credits.setPadding(0,dp(20),0,dp(12)); column.addView(credits);
        try {
            String saved = SessionVault.read("settings");
            if (!saved.isEmpty()) {
                JSONArray settings = new JSONArray(saved);
                EditText[] list = fields();
                for (int i=0; i<list.length; i++) if (i != 3 && i != 4) list[i].setText(settings.optString(i));
                ownApi.setChecked("1".equals(settings.optString(9)));
            }
        } catch (Exception error) { show("Не удалось открыть защищённые данные. Очистите данные приложения и войдите заново."); }
    }

    private EditText field(LinearLayout parent, String hint, int type) {
        EditText view = new EditText(this);
        view.setHint(hint);
        view.setInputType(type);
        view.setTextColor(Color.WHITE); view.setHintTextColor(Color.rgb(138,153,173));
        view.setTextSize(15); view.setSingleLine(true); view.setSaveEnabled(false);
        if (android.os.Build.VERSION.SDK_INT >= 26) view.setImportantForAutofill(View.IMPORTANT_FOR_AUTOFILL_NO_EXCLUDE_DESCENDANTS);
        view.setPadding(dp(12),dp(10),dp(12),dp(10));
        GradientDrawable bg = new GradientDrawable(); bg.setColor(Color.rgb(25,32,42));
        bg.setCornerRadius(dp(8)); bg.setStroke(dp(1),Color.rgb(63,78,95)); view.setBackground(bg);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1,dp(52)); params.topMargin=dp(8);
        parent.addView(view,params);
        return view;
    }
    private Button button(LinearLayout parent, String title, Runnable action) {
        Button view = new Button(this);
        view.setText(title);
        view.setOnClickListener(v -> {
            view.setText("Нажато…");
            view.postDelayed(() -> view.setText(title), 700);
            action.run();
        });
        view.setAllCaps(false); view.setTextColor(Color.WHITE); view.setTextSize(15);
        GradientDrawable bg = new GradientDrawable(); bg.setColor(blue); bg.setCornerRadius(dp(8));
        GradientDrawable mask = new GradientDrawable(); mask.setColor(Color.WHITE); mask.setCornerRadius(dp(8));
        view.setBackground(new RippleDrawable(ColorStateList.valueOf(Color.argb(110,255,255,255)), bg, mask));
        view.setOnTouchListener((target,event) -> {
            if (event.getActionMasked() == MotionEvent.ACTION_DOWN)
                target.animate().scaleX(0.97f).scaleY(0.97f).setDuration(70).start();
            else if (event.getActionMasked() == MotionEvent.ACTION_UP || event.getActionMasked() == MotionEvent.ACTION_CANCEL)
                target.animate().scaleX(1f).scaleY(1f).setDuration(120).start();
            return false;
        });
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1,dp(50)); params.topMargin=dp(10);
        parent.addView(view,params);
        return view;
    }
    private LinearLayout card(LinearLayout parent, String title) {
        LinearLayout card = new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14),dp(14),dp(14),dp(16));
        GradientDrawable bg = new GradientDrawable(); bg.setColor(Color.rgb(28,34,43)); bg.setCornerRadius(dp(14)); card.setBackground(bg);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1,-2); params.topMargin=dp(16); parent.addView(card,params);
        TextView label = new TextView(this); label.setText(title); label.setTextSize(18); label.setTextColor(Color.WHITE);
        label.setTypeface(null,Typeface.BOLD); card.addView(label); return card;
    }
    private EditText[] fields() { return new EditText[]{apiId,apiHash,phone,code,password,proxyHost,proxyPort,proxyUser,proxyPassword}; }
    private void cleanExports() {
        File[] files = getCacheDir().listFiles((dir,name) -> name.startsWith("telegram-chat-export"));
        if (files != null) for (File file : files) file.delete();
    }
    private interface Task { void run() throws Exception; }
    private void runTask(Task task) {
        EditText[] input = fields(); values = new String[input.length];
        JSONArray settings = new JSONArray();
        for (int i=0;i<input.length;i++) { values[i]=input[i].getText().toString(); settings.put(i==3 || i==4 ? "" : values[i]); }
        settings.put(overrideApi ? "1" : "0");
        if (!overrideApi) { values[0] = Credentials.id(); values[1] = Credentials.hash(); }
        if (values[0].trim().isEmpty() || values[1].trim().isEmpty()) {
            new AlertDialog.Builder(this).setTitle("Нужны данные Telegram API")
                .setMessage("Для этой программы одного номера телефона недостаточно. Введите API ID и API Hash с my.telegram.org/apps. В публичной сборке встроенные ключи уже настроены. Если выбраны собственные API-данные, заполните оба поля в дополнительных настройках.")
                .setNegativeButton("Понятно", (dialog,which) -> { apiId.requestFocus(); apiId.requestRectangleOnScreen(new Rect(0,0,apiId.getWidth(),apiId.getHeight()),false); })
                .setPositiveButton("Открыть сайт", (dialog,which) -> {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://my.telegram.org/apps"))); }
                    catch (android.content.ActivityNotFoundException error) { show("Откройте my.telegram.org/apps в браузере."); }
                }).show();
            return;
        }
        if (!values[5].trim().isEmpty() && values[6].trim().isEmpty()) { show("Введите порт SOCKS5-прокси или очистите его адрес для работы напрямую/VPN."); return; }
        InputMethodManager keyboard = (InputMethodManager)getSystemService(INPUT_METHOD_SERVICE);
        if (keyboard != null) keyboard.hideSoftInputFromWindow(root.getWindowToken(), 0);
        setBusy(true);
        worker.execute(() -> {
            try { SessionVault.write("settings", settings.toString()); task.run(); }
            catch (Exception e) {
                if (exportFile != null) exportFile.delete();
                String detail = String.valueOf(e.getMessage());
                if (detail.contains("Connection to Telegram failed"))
                    show("Нет соединения с серверами Telegram. Включите VPN или настройте SOCKS5-прокси и повторите.");
                else show(friendlyError(detail));
            }
            finally { if (exportFile == null || !exportFile.exists()) setBusy(false); }
        });
    }
    private String friendlyError(String detail) {
        if (detail.contains("PhoneCodeInvalid")) return "Неверный код Telegram. Проверьте код и повторите вход.";
        if (detail.contains("PhoneCodeExpired")) return "Код истёк. Запросите новый код.";
        if (detail.contains("PhoneNumberInvalid")) return "Проверьте номер телефона в международном формате: +код страны и номер.";
        if (detail.contains("PasswordHashInvalid")) return "Неверный облачный пароль Telegram.";
        if (detail.contains("FloodWait")) return "Telegram временно ограничил попытки. Подождите и повторите позже.";
        if (detail.contains("ApiIdInvalid")) return "Telegram отклонил API-данные. Проверьте дополнительные настройки.";
        if (detail.contains("ValueError")) return "Проверьте введённые данные и убедитесь, что вход выполнен.";
        return "Не удалось выполнить действие. Проверьте вход, подключение к интернету и настройки VPN/прокси.";
    }
    private void setBusy(boolean busy) {
        runOnUiThread(() -> {
            sendCode.setEnabled(!busy); signIn.setEnabled(!busy);
            enterPassword.setEnabled(!busy); loadChats.setEnabled(!busy); export.setEnabled(!busy); logout.setEnabled(!busy);
            for (EditText field : fields()) field.setEnabled(!busy);
            apiId.setEnabled(!busy && overrideApi); apiHash.setEnabled(!busy && overrideApi);
            for (Button button : new Button[]{sendCode,signIn,enterPassword,loadChats,export,logout}) button.setAlpha(busy ? 0.5f : 1f);
            progress.setVisibility(busy ? View.VISIBLE : View.GONE);
            if (busy) {
                status.setText("Обработка… Для большой истории это может занять время.");
                bottomMessage("Обработка началась…");
                revealStatus();
            }
        });
    }
    private void revealStatus() {
        status.post(() -> status.requestRectangleOnScreen(new Rect(0,0,status.getWidth(),status.getHeight()),false));
    }
    private void show(String message) { runOnUiThread(() -> {
        status.setText(message); bottomMessage(message); revealStatus();
    }); }
    private void bottomMessage(String message) {
        messageHandler.removeCallbacks(dismissMessage);
        floatingMessage.animate().cancel(); floatingMessage.setText(message); floatingMessage.setVisibility(View.VISIBLE);
        floatingMessage.setAlpha(0f); floatingMessage.setTranslationY(dp(12));
        floatingMessage.animate().alpha(1f).translationY(0f).setDuration(180).withEndAction(null).start();
        messageHandler.postDelayed(dismissMessage, 5500);
    }
    private PyObject bridge() { return Python.getInstance().getModule("telegram_bridge"); }
    private String sessionDir() { return new File(getFilesDir(), "session").getAbsolutePath(); }
    private String api() { return values[0].trim(); }
    private String hash() { return values[1].trim(); }
    private String proxyHost() { return values[5].trim(); }
    private String proxyPort() { return values[6].trim(); }
    private String proxyUser() { return values[7]; }
    private String proxyPassword() { return values[8]; }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != 101) return;
        if (resultCode != RESULT_OK || data == null) {
            if (exportFile != null) exportFile.delete();
            setBusy(false);
            show("Сохранение отменено.");
            return;
        }
        Uri destination = data.getData();
        if (destination == null || exportFile == null) { cleanExports(); setBusy(false); show("Не выбрано место сохранения."); return; }
        setBusy(true);
        worker.execute(() -> {
            try (FileInputStream input = new FileInputStream(exportFile);
                 OutputStream output = getContentResolver().openOutputStream(destination)) {
                if (output == null) throw new IllegalStateException("Не удалось открыть файл.");
                byte[] buffer = new byte[32768];
                int size;
                while ((size = input.read(buffer)) != -1) output.write(buffer, 0, size);
                show("Готово. Файл сохранён в выбранном месте.");
            } catch (Exception e) { show("Ошибка сохранения: " + e.getMessage()); }
            finally { exportFile.delete(); setBusy(false); }
        });
    }
    @Override protected void onDestroy() { messageHandler.removeCallbacks(dismissMessage); super.onDestroy(); worker.shutdown(); }
}
