plugins {
    id("com.android.application")
    id("com.chaquo.python")
}

android {
    namespace = "org.example.telegramtextexport"
    compileSdk = 35
    defaultConfig {
        applicationId = "org.example.telegramtextexport"
        minSdk = 24
        targetSdk = 35
        versionCode = 7
        versionName = "v1.0"
        ndk { abiFilters += listOf("arm64-v8a") }
    }
    signingConfigs {
        create("publication") {
            val keyPath = System.getenv("TE_EXPORT_KEYSTORE")
            if (keyPath != null) {
                storeFile = file(keyPath)
                storePassword = System.getenv("TE_EXPORT_STORE_PASSWORD")
                keyAlias = "telegram-export"
                keyPassword = System.getenv("TE_EXPORT_STORE_PASSWORD")
            }
        }
    }
    buildTypes { getByName("release") { isDebuggable = false; isMinifyEnabled = true; proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro"); signingConfig = signingConfigs.getByName("publication") } }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

chaquopy {
    defaultConfig {
        version = "3.12"
        pip {
            options("--no-index", "--find-links", "wheels")
            install("Telethon==1.45.0")
            install("python-socks[asyncio]==2.7.3")
        }
    }
}

// Public sources contain no developer API values. Supply them in the build environment.
val generatedCredentials = layout.buildDirectory.dir("generated/credentials")
val generateCredentials by tasks.registering {
    outputs.upToDateWhen { false }
    doLast {
        val apiId = System.getenv("TE_EXPORT_API_ID") ?: ""
        val apiHash = System.getenv("TE_EXPORT_API_HASH") ?: ""
        val directory = generatedCredentials.get().asFile.resolve("org/example/telegramtextexport")
        directory.mkdirs()
        fun encoded(value: String, mask: Int) = value.toByteArray(Charsets.UTF_8).joinToString(",") { ((it.toInt() and 255) xor mask).toString() }
        directory.resolve("Credentials.java").writeText("""
            package org.example.telegramtextexport;
            public final class Credentials {
                private static String decode(int[] input, int mask) {
                    byte[] output = new byte[input.length];
                    for (int i = 0; i < input.length; i++) output[i] = (byte)(input[i] ^ mask);
                    return new String(output, java.nio.charset.StandardCharsets.UTF_8);
                }
                public static String id() { return decode(new int[]{${encoded(apiId, 91)}}, 91); }
                public static String hash() { return decode(new int[]{${encoded(apiHash, 37)}}, 37); }
            }
        """.trimIndent())
    }
}
android.sourceSets.getByName("main").java.srcDir(generatedCredentials)
tasks.named("preBuild").configure { dependsOn(generateCredentials) }
